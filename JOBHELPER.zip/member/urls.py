from . import views
from django.urls import path

app_name ='member'
urlpatterns = [
    
    # 회원가입페이지
    path('signup/',views.signup,name='signup'),
    # 마이페이지
    path('mypage/',views.mypage,name='mypage'),
    # 정보수정페이지
    path('modify/',views.membermodify,name='membermodify'),
    # 수정완료(DB반영)
    path('memberupdated/',views.memberupdated,name='memberupdated'),
    # 로그인페이지
    path('login/',views.login,name='login'),
    # 로그아웃
    path('logout/',views.logout,name='logout'),
    # 탈퇴
    path('delete/',views.memberdrop,name='memberdrop'),
    # 분석
    path('analsys/',views.analsys,name='analsys'),
    
]

 
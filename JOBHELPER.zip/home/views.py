from django.shortcuts import render
from resume.models import ResumeForm
# Create your views here.

def index(request):
    qs = ResumeForm.objects.all()
    print(qs)
    context={'detail':qs}
    return render(request,'index.html',context)

# def resume_menu(request):
#     return render(request,'resume_menu.html')
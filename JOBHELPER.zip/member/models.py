from django.db import models
# from datetime import datetime
import datetime as dt

# Create your models here.
# # 개인 정보 사항 데이터 focus
class Memberdata(models.Model):
    id = models.CharField(max_length=40,primary_key=True)
    pw = models.CharField(max_length=300)
    name = models.CharField(max_length=100)
    nickname = models.CharField(max_length=100)
    email_id = models.CharField(max_length=200)
    email_domain = models.CharField(max_length=200)
    skill = models.CharField(max_length=500)
    ## 맴버유형변수 - membertype-> 지원자,전문가
    membertype = models.CharField(max_length=1000)
    ## 전문가 자료 파일 이미지 첨부
    image = models.ImageField(blank=True)
   
    
 ## 학력정보-고등학교,2-3년제,4년제,대학원(석사,박사)
class Education(models.Model):
    e_no = models.AutoField(primary_key=True)
    college = models.CharField(max_length=100)
    univ_name = models.CharField(max_length=100)
    # univ_start = models.DateTimeField(blank=True,auto_now_add=True)
    # univ_end = models.DateTimeField(blank=True,auto_now_add=True)
    start_type = models.CharField(max_length=20) 
    end_type = models.CharField(max_length=20) 
    deptmajor = models.CharField(max_length=100)
    add_dept = models.CharField(max_length=100)
    GPA = models.FloatField(default=0)   
    GPA_std =models.FloatField(default=0)
    
    def __str__(self):
        return self.e_no
  
## 경력사항
class Careerpath(models.Model):
    corp_name = models.CharField(max_length=250)
    # corp_in = models.DateTimeField(blank=True,auto_now_add=True)
    # corp_out = models.DateTimeField(blank=True,auto_now_add=True)
    corp_ing = models.CharField(max_length=200)
    corp_position = models.CharField(max_length=100)
    job_grade = models.CharField(max_length=200)
    corp_dept = models.CharField(max_length=200)
    salary = models.IntegerField(default=0)
    duty_res =models.CharField(max_length=600)
    
    def __str__(self):
        return self.corp_name 
    
## 대외활동
class Activities(models.Model):
    act_type = models.CharField(max_length=50)        
    act_associ = models.CharField(max_length=100)
    # act_start = models.DateTimeField(blank=True, auto_now_add=True)
    # act_end = models.DateTimeField(blank=True,auto_now_add=True)
    act_detail = models.CharField(max_length=1000)
    thesis = models.CharField(max_length=400)
    
    def __str__(self):
        return self.act_associ




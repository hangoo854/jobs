from django.contrib import admin
from member.models import Memberdata,Education
# Register your models here.

@admin.register(Memberdata)
class MeberAdmin(admin.ModelAdmin):
    list_display = ['nickname','email_id','email_domain','membertype','name','skill']
    
@admin.register(Education)
class EduAdmin(admin.ModelAdmin):
    list_display = ['e_no','college','univ_name','deptmajor']    

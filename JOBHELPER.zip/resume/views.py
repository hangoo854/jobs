from asyncio.windows_events import NULL
from django.shortcuts import render,redirect
import cx_Oracle as ora
from django.http import HttpResponse, JsonResponse,HttpResponseRedirect
from .models import Reply
from resume.models import ResumeForm,Education,Careerpath,Activities
from member.models import Memberdata
from django.urls import reverse
from django.db.models import F,Q
from datetime import datetime
# Create your views here.


## Write -> 개인세부리스트작성(개인이력서작성)
def resume_write(request):
    if request.method == 'GET':
        return render(request,'resume_write.html')
    else:
        ## form 데이터
        id = request.session['session_id']
        qs = Memberdata.objects.get(id=id)
        name = qs.name
        nickname = qs.nickname
        title = request.POST.get('title')
        member = Memberdata.objects.get(name=name,nickname=nickname)
        college = request.POST.get('edutype')
        univ_name = request.POST.get('univname')
        request.session.univtype = univ_name
        # univ_start = request.POST.get('univin')
        # univ_end = request.POST.get('univout')
        start_type =request.POST.get('typein')
        end_type = request.POST.get('typeout')
        deptmajor = request.POST.get('major')
        add_dept = request.POST.get('adegree')
        GPA = request.POST.get('gpa')
        GPA_std = request.POST.get('gpastd')
        r_content = request.POST.get('content') 
        r_education = Education.objects.create(college=college,univ_name=univ_name,start_type=start_type,end_type =end_type ,deptmajor=deptmajor,\
                add_dept=add_dept,GPA=GPA)
         ## DB에 저장
        qs = ResumeForm(r_title=title,member=member,r_education=r_education,r_content=r_content)
        qs.save()
        qs.r_group = qs.r_no
        qs.save()
        print('학력정보기입완료!!!')
        return redirect('resume:resume_board')
        
## 오라클 local 접속
def oracleconn():
    try:
        conn =  ora.connect('ora_cv/1234@localhost:1521/xe')
    except:
        print('DB 에러')
    return conn
        

def makeDictFactory(cursor):
    columnNames = [d[0] for d in cursor.description]
    def createRow(*args):
        return dict(zip(columnNames,args))
    return createRow
 
## 학력테이블연결
def education_db(request):
    conn = oracleconn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM MEMBER_EDUCATION")

## 고등학교조건
def highschool_db(request):
    conn = oracleconn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM MEMBER_EDUCATION WHERE COLLEGE ='고등학교'")
        
# ## 경력테이블연결
# def education_db(request):
#     conn = oracleconn()
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM MEMBER_CAREERPATH")
    

# ## 활동테이블연결
# def education_db(request):
#     conn = oracleconn()
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM MEMBER_ACTIVITIES")    
       
## list -> 개인별이력서리스트
def resume_board(request):
    qs = ResumeForm.objects.all()
    # qs2 = Education.objects.all()
    
    # college=Education.objects.filter(college__in=['고등학교','univ','college','석사','박사'])
    
    # qs1,qs2,qs3,qs4,qs5='','','','',''
    # qsr1,qsr2,qsr3,qsr4,qsr5='','','','',''
    # print('cooll:: ',college)
    # print('cooll  ::',Education.objects.filter(college__contains='univ'))
    
    # if college =='college':
    #     qs2 = Education.objects.get(college='college')
    #     qsr2 = ResumeForm.objects.get(r_education=qs2)
    # elif college['college']== Education.objects.filter(college__contains='univ') :
    #     qs3 = Education.objects.get(college='univ')
    #     qsr3 = ResumeForm.objects.get(r_education=qs3)
    #     print('univunivuniv')
    # elif college == '석사':
    #     qs4 = Education.objects.get(college='석사')
    #     qsr4 = ResumeForm.objects.get(r_education=qs4)
    # elif college == '박사':
    #     qs5 = Education.objects.get(college='박사')
    #     qsr5 = ResumeForm.objects.get(r_education=qs5) 
    # elif college=='고등학교':
    #     qs1 = Education.objects.get(college='고등학교')
    #     qsr1 = ResumeForm.objects.get(r_education=qs1)    
    # else:
    #     qs = ResumeForm.objects.all()
    # qs2 = ResumeForm.objects.get(r_education=qs)
    context = {'detail':qs}
    return render(request,'resume_list.html',context)
    
    
   
   
   
  
   
   
   
   
   
        
       
       
## 이력서 메뉴
def resume_menu(request):
   
    # qs= Education.objects.get(college=college)
    qs =Education.objects.all()
    # expert = Memberdata.objects.filter(membertype__contains='전문가')
    # print('college',qs)
    
    # qsr = ResumeForm.objects.get(r_education=qs)
    qsr = ResumeForm.objects.all()
    
  
    context = {'edu':qs,'detail':qsr}
    return render(request,'resume_menu.html',context)
  
    
## View -> 세부리스트보기
def resume_view(request,r_no):
    qsr = ResumeForm.objects.get(r_no=r_no)
    
    # if not qsr.r_education.college:
    #     qsr.r_education.college='1'
    #     college= int(qsr.r_education.college)
        
            
    e_no= qsr.r_education.e_no   
    college= qsr.r_education.college
    title = qsr.r_title
        
    qs,qs1,qs2,qs3,qs4,qs5='','','','','',''
    qsr1,qsr2,qsr3,qsr4,qsr5='','','','',''
    print('e_no : ',e_no)
    # qs = Education.objects.get(e_no=e_no)
    print('college : ', college)
    
    if college=='college':
        qs2 = Education.objects.get(college=college)
        # qsr2 = ResumeForm.objects.get(r_education=qs2)
        qsr2 = ResumeForm.objects.filter(r_education=qs2).get(r_no=r_no)
    elif college == 'univ':
        qs3 = Education.objects.get(college=college)
        # qsr3 = ResumeForm.objects.get(r_education=qs3)
        # print('qs3: ', int(qs3))
        qsr3 = ResumeForm.objects.filter(r_education=qs3).get(r_no=r_no)
        print('qsr3: ', qsr3)
    elif college == '석사':
        qs4 = Education.objects.get(college=college)
        qsr4 = ResumeForm.objects.filter(r_education=qs4).get(r_no=r_no)
    elif college == '박사':
        qs5 = Education.objects.get(college=college)
        qsr5 = ResumeForm.objects.filter(r_education=qs5).get(r_no=r_no)
    elif college == '고등학교':
        qs1 = Education.objects.get(college=college)
        qsr1 = ResumeForm.objects.filter(r_education=qs1).get(r_no=r_no)
    else:
        title = ResumeForm.objects.get(r_title=title)
        qsr = ResumeForm.objects.get(r_education=qs)
        print('qsr : ', qsr)         
    # qs1= Education.objects.distinct('college')
    print('qsr__ : ', qsr)
    print('qsr3__ : ', qsr3)
    context = {'detail':qsr,'detail1':qsr1,'detail2':qsr2,'detail3':qsr3,'detail4':qsr4,'detail5':qsr5,\
       'coll':college,'eid':qs, 'high':qs1,'coll':qs2,'uni':qs3,'mas':qs4,'doc':qs5,'title':title}
    return render(request,'resume_view.html',context)
    
   
    
    
    
   

## highschool_list -> 고등학교이력
def highschool_board(request):
    
    qs = Education.objects.order_by('-id')
    qs2 = ResumeForm.objects.get(r_education=qs)
    print('고등학교 board 함수 호출')
    context = {'high':qs,'list_view':qs2}
    print('highschool_list 보기')
    return render(request,'highschool_list.html',context)
    
## View -> 고등학교세부리스트보기
def highschool_view(request):
    
    qs = Education.objects.get(college='고등학교')
    print(qs)
    if qs.college =='고등학교':
        qs2= ResumeForm.objects.get(r_education=qs)
       
       
        print('college : ',qs2.r_education.college)
        print('dept : ',qs2.r_education.deptmajor)
        context = {'list_view':qs,'high':qs2}
        print('highschool_view 보기')
        return render(request,'highschool_view.html',context)
    else:
        print('highschool_view 보기 실패')
        return redirect('/')
    
## 이력서삭제(탈퇴)
def resumedelete(request,r_no):
    if request.method == 'GET':
       
       
        qs = ResumeForm.objects.get(r_no=r_no)
        qs.delete()
        print('resume delete completed !!')
        
        return redirect('/')

## 고등학교항목삭제
def highschooldelete(request,college):
    if request.method == 'GET':
       
        qs = Education.objects.get(college=college)
        if qs =='고등학교':
            qs.delete()
            print('highschooldelete completed !!')
        else:
            print('delete fail..')
        
        return redirect('resume_view.html')

## 고등학교 write
def tab1(request):
    if request.method == 'GET':
            
        return render(request,'highschool_write.html')
    else:
        ## form 데이터
        
        id = request.session['session_id']
        qs = Memberdata.objects.get(id=id)
        name = qs.name
        nickname = qs.nickname
        title = request.POST.get('title')
        member = Memberdata.objects.get(name=name,nickname=nickname)

        college = '고등학교'
       
        univ_name = request.POST.get('univname')
        # univ_start = request.POST.get('univin')
        # univ_end = request.POST.get('univout')
        start_type =request.POST.get('typein')
        end_type = request.POST.get('typeout')
        deptmajor = request.POST.get('major')
        # add_dept = request.POST.get('adegree')
        GPA = request.POST.get('gpa')
        # GPA_std = request.POST.get('gpastd') 

        r_education = Education.objects.create(college=college,univ_name=univ_name,start_type=start_type,end_type =end_type ,deptmajor=deptmajor,\
                GPA=GPA)
        # DB에 저장
        qs = ResumeForm(r_title=title,member=member,r_education=r_education)
        qs.save()
        qs.r_group = qs.r_no
        qs.save()
        print('고등학교정보이력서생성!!')
        return redirect('resume:resume_board')

      
    
   
       

def tab2(request):
     if request.method == 'GET':
            
        return render(request,'college_write.html')
     else:
        ## form 데이터
        
        id = request.session['session_id']
        qs = Memberdata.objects.get(id=id)
        name = qs.name
        nickname = qs.nickname
        title = request.POST.get('title')
        member = Memberdata.objects.get(name=name,nickname=nickname)
        college = 'college'
        univ_name = request.POST.get('univname')
        # univ_start = request.POST.get('univin')
        # univ_end = request.POST.get('univout')
        start_type =request.POST.get('typein')
        end_type = request.POST.get('typeout')
        deptmajor = request.POST.get('major')
        add_dept = request.POST.get('adegree')
        GPA = request.POST.get('gpa')
        GPA_std = request.POST.get('gpastd') 
       
        r_education = Education.objects.create(college=college,univ_name=univ_name,start_type=start_type,end_type =end_type ,deptmajor=deptmajor,\
                add_dept=add_dept,GPA=GPA, GPA_std= GPA_std)
         ## DB에 저장
        qs = ResumeForm(r_title=title,member=member,r_education=r_education)
        qs.save()
        qs.r_group = qs.r_no
        qs.save()
        print('학력정보기입완료!!!')
        return redirect('resume:resume_board')
    
       
        
        

def tab3(request):
    if request.method == 'GET':
        
        return render(request,'univ_write.html')
    else:
        ## form 데이터
        
        id = request.session['session_id']
        qs = Memberdata.objects.get(id=id)
        name = qs.name
        nickname = qs.nickname
        title = request.POST.get('title')
        member = Memberdata.objects.get(name=name,nickname=nickname)
        college = 'univ'
        univ_name = request.POST.get('univname')
        # univ_start = request.POST.get('univin')
        # univ_end = request.POST.get('univout')
        start_type =request.POST.get('typein')
        end_type = request.POST.get('typeout')
        deptmajor = request.POST.get('major')
        add_dept = request.POST.get('adegree')
        GPA = request.POST.get('gpa')
        GPA_std = request.POST.get('gpastd') 
        r_education = Education.objects.create(college=college,univ_name=univ_name,start_type=start_type,end_type =end_type ,deptmajor=deptmajor,\
                add_dept=add_dept,GPA=GPA, GPA_std= GPA_std)
         ## DB에 저장
        qs = ResumeForm(r_title=title,member=member,r_education=r_education)
        qs.save()
        qs.r_group = qs.r_no
        qs.save()
        print('학력정보기입완료!!!')
        return redirect('resume:resume_board')
       
     
  
       
    
  
def tab4(request):
    if request.method == 'GET':
            
        return render(request,'graduate_write.html')
    else:
        ## form 데이터
        
        id = request.session['session_id']
        qs = Memberdata.objects.get(id=id)
        name = qs.name
        nickname = qs.nickname
        title = request.POST.get('title')
        member = Memberdata.objects.get(name=name,nickname=nickname)
        college = request.POST.get('edutype')
        r_content = request.POST.get('content')
        if college =='master':
            college ='석사'
        elif  college =='doctor':
            college ='박사'
        else:
            college='석박사통합'
        univ_name = request.POST.get('univname')
        # univ_start = request.POST.get('univin')
        # univ_end = request.POST.get('univout')
        start_type =request.POST.get('typein')
        end_type = request.POST.get('typeout')
        deptmajor = request.POST.get('major')
        add_dept = request.POST.get('adegree')
        GPA = request.POST.get('gpa')
        GPA_std = request.POST.get('gpastd') 
        
        r_education = Education.objects.create(college=college,univ_name=univ_name,start_type=start_type,end_type =end_type ,deptmajor=deptmajor,\
                add_dept=add_dept,GPA=GPA, GPA_std= GPA_std)
         ## DB에 저장
        qs = ResumeForm(r_title=title,member=member,r_education=r_education, r_content= r_content)
        qs.save()
        qs.r_group = qs.r_no
        qs.save()
        print('학력정보기입완료!!!')
        return redirect('resume:resume_board')


    
## Reply -> 답글(detail) 및 댓글(전문가의  피드백)



# 게시판 답글쓰기 함수
def Rreply(request,r_no):
    if request.method == 'GET':
        qs = ResumeForm.objects.get(r_no=r_no) 
        context={'re':qs}
        return render(request,'reply.html',context)
    else:
        # id = request.session.session_id
        id = request.POST.get('id')
        
        member = Memberdata.objects.get(id=id)
        # edu = Education.objects.get(r_education=resu)
        qs = ResumeForm.objects.get(r_no=r_no) 
        college = qs.r_education.college
        print('college',college)
        print("id:",id)
      
        group = int(qs.r_group)
        step = int(qs.r_step)
        indent = int(qs.r_indent)
        
       
        
        title = request.POST.get('r_title')
        content = request.POST.get('content')
        print('title',title)
        print('content',content)
        print('group',group)
        print('step',step)
        print('indent',indent)
        ResumeForm.objects.filter(r_group=group,r_step__gt=step).update(r_step=F('r_step')+1)
        r_education = Education.objects.get(college=college)
        
        # step: 출력순서, indent: 들여쓰기
        # qs= Reply(member=member,r_title=title,r_content=content,r_group=group\
        #     ,r_step=step+1,r_indent=indent+1)
        qs=  ResumeForm(member=member,r_title=title,r_content=content\
            ,r_education= r_education,r_group=group,r_step=step+1,r_indent=indent+1)
        qs.save() # f_no
        
        return redirect('resume:resume_board')
    




# 댓글 수정 저장 update
def commUpdateOk(request):
    c_no = request.GET.get('c_no')
    c_content = request.GET.get('c_content')
    id = request.session.get('session_id')
    print("commUpdateOk : ",c_no,c_content,id)
    # 해당데이터 검색
    qs = Reply.objects.get(c_no=c_no)
    qs.c_content = c_content
    qs.c_date=datetime.now()
    qs.save()
    # ajax으로 전송
    context={'c_no':c_no,'c_content':c_content,'c_date':qs.c_date,'result':'댓글이 수정되었습니다.'}
    return JsonResponse(context)


# 댓글 delete
def commDelete(request):
    c_no = request.GET.get('c_no')
    qs = Reply.objects.get(c_no=c_no)
    qs.delete()
    context={'result':'댓글이 삭제되었습니다.'}
    return JsonResponse(context)


# 댓글 write - Query : dic타입
def commWrite(request):
    # html페이지에서 데이터 가져오기
    id = request.session.get('session_id')
    member = Memberdata.objects.get(id=id)
    r_no = request.GET.get('r_no')
    reboard = ResumeForm.objects.get(c_no=c_no)
    pw = request.GET.get('pw')
    content = request.GET.get('content')
    # db에 저장
    qs = Reply(member=member,form=reboard,c_pw=pw,c_content=content)
    qs.save()
    # 댓글번호 넘겨줌
    c_no = qs.c_no
    c_date = qs.c_date
    # 저장데이터 : c_no,member,fboard,c_pw,c_content,c_date
    context={"c_no":c_no,"r_no":r_no,"c_pw":pw,"c_content":content,"c_date":c_date}
    return JsonResponse(context)


# 댓글 list - QuerySet : List타입
def commList(request):
    r_no = request.GET.get('r_no')
    print("r_no commList : ",r_no)
    # f_no 하단댓글을 검색
    qs = Reply.objects.filter(form=r_no).order_by('-c_no')
    # list타입으로 전송 : safe=False
    clist = list(qs.values()) # [0:q1,1:q2,2:q3]
    return JsonResponse(clist,safe=False) 

    # HttpResponse : json타입 - dic타입
    # clist = serializers.serialize('json',qs)
    # return HttpResponse(clist,content_type='text/json-comment-filtered')
    
    # JsonResponse : dic타입으로 전송
    # context={"clist":clist}
    # # context={'reload_all':False,"clist":clist}
    # return JsonResponse(context)    


from django.db import models


# Create your models here.
## Ques1 성장과정 
class Ques1(models.Model):
    subques1 = models.CharField(max_length=30)
    ## subques1 분류필드
    ques_content1 = models.CharField(max_length=2000)
    ## ques_content1 내용
    ques_keyword1 = models.CharField(max_length=200)
    ## ques_keyword1 키워드


## Ques2 성격의 장단점
class Ques2(models.Model):
    subques2 = models.CharField(max_length=30)
    ## subques2 분류필드
    ques_content2 = models.CharField(max_length=2000)
    ## ques_content2 내용
    ques_keyword2 = models.CharField(max_length=200)
    ## ques_keyword2 키워드

    
## Ques3 성격의 장단점
class Ques3(models.Model):
    subques3 = models.CharField(max_length=30)
    ## subques3 분류필드
    ques_content3 = models.CharField(max_length=2000)
    ## ques_content3 내용
    ques_keyword3 = models.CharField(max_length=200)
    ## ques_keyword3 키워드


## Ques4 기타질의
class Ques4(models.Model):
    subques4 = models.CharField(max_length=30)
    ## subques4 기타필드
    ques_content4 = models.CharField(max_length=2000)
    ##  ques_content4 내용
    ques_keyword4 = models.CharField(max_length=200)
    ##  ques_keyword4내용


## Qees5 직무경험
## class Ques5(models.Model):




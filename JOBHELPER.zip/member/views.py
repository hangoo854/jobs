from django.shortcuts import redirect, render,redirect
import cx_Oracle as ora
from django.http import HttpResponseRedirect
from django.urls import reverse
from resume.models import ResumeForm
from member.models import Memberdata,Education,Careerpath,Activities

# Create your views here.

            
##마이페이지
def mypage(request):
   
    id = request.session['session_id']
    qs = Memberdata.objects.get(id=id)
    print('qs: ',qs)
    print('id: ',qs.id)
    print('name: ',qs.name)
    context = {'list':qs}
    
    return render(request,'mypage.html', context )


## 오라클 local 접속
def oracleconn():
    try:
        conn =  ora.connect('ora_cv/1234@localhost:1521/xe')
    except:
        print('DB 에러')
    return conn
        

def makeDictFactory(cursor):
    columnNames = [d[0] for d in cursor.description]
    def createRow(*args):
        return dict(zip(columnNames,args))
    return createRow

## 회원가입
def signup(request):
    if request.method =='GET':
        return render(request,'signup.html')
    else:
        try:
            id = request.POST.get('id')
            qs = Memberdata.objects.get(id=id)
            msg='이미 존재하는 아이디입니다. 다른 아이디를 입력하세요'
            return render(request,'signup.html',{'msg':msg})
        except:
            if request.POST['pw'] == request.POST['repw']:
                id = request.POST.get('id')
                pw = request.POST.get('pw')
                name = request.POST.get('name')
                nickname = request.POST.get('nick')
                membertype = request.POST.get('mtype')
                email_id = request.POST.get('email_id')
                email_domain = request.POST.get('domain')
                # certifi = request.POST.get('certifi')
                # award = request.POST.get('award')
                skill = request.POST.get('skill')
                files = request.FILES.get('file')
                # Memberdata.objects.create(id=id,pw=pw,\
                #     name=name,nickname=nickname,\
                #         membertype=membertype,email_id=email_id,email_domain=email_domain\
                #             ,skill=skill,image=image)
                Memberdata.objects.create(id=id,pw=pw,\
                    name=name,nickname=nickname,\
                        membertype=membertype,email_id=email_id,email_domain=email_domain\
                            ,skill=skill,image=files)
                Memberdata(id=id,pw=pw,\
                    name=name,nickname=nickname,\
                        membertype=membertype,email_id=email_id,email_domain=email_domain\
                            ,skill=skill,image=files)
                print('insert completed!')

                return redirect('/')
            else:
                msg = '패스워드와 패스워드 확인 부분이 불일치합니다. 다시 입력하세요'
                return render(request,'signup.html',{'msg':msg})
            
 


## 로그인 이벤트 발생 - 회원테이블 DB연결
def members(request):
    conn = oracleconn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM MEMBER_MEMBERDATA")

# ## 학력사항입력
def education(request):
    if request.method =='POST':
        collage = request.POST.get('edutype')
        univ_name = request.POST.get('univname')
        # univ_start = request.POST.get('univin')
        # univ_end = request.POST.get('univout')
        start_type =request.POST.get('typein')
        end_type = request.POST.get('typeout')
        deptmajor = request.POST.get('major')
        add_dept = request.POST.get('adegree')
        GPA = request.POST.get('gpa')
        GPA_std = request.POST.get('gpastd')
        # Education.objects.create(collage=collage,univ_name=univ_name,univ_start=univ_start,\
        #     univ_end =univ_end,start_type=start_type,end_type =end_type ,deptmajor=deptmajor,\
        #         add_dept=add_dept,GPA=GPA, GPA_std= GPA_std)
        Education.objects.create(collage=collage,univ_name=univ_name,start_type=start_type,end_type =end_type ,deptmajor=deptmajor,\
                add_dept=add_dept,GPA=GPA, GPA_std= GPA_std)
        print('학력정보기입완료!!!')
        return HttpResponseRedirect(reverse('resume:resume_write'))  
    

## 학력테이블연결
def education_db(request):
    conn = oracleconn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM MEMBER_EDUCATION")

## 경력테이블연결
def education_db(request):
    conn = oracleconn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM MEMBER_CAREERPATH")
    

## 활동테이블연결
def education_db(request):
    conn = oracleconn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM MEMBER_ACTIVITIES")    

## 로그인
def login(request):
    if request.method == 'GET':
        qs =ResumeForm.objects.all()
        context = {'detail':qs}
        return render(request,'signin.html',context)
    else: 
        id = request.POST.get('id')
        pw = request.POST.get('pw')
        
        try:
            qs = Memberdata.objects.get(id=id,pw=pw)
        except Memberdata.DoesNotExist:
            # msg = '아직 회원가입 하지 않았습니다.'
            # print(msg)
            # return HttpResponse(request,'signin.html',{'msg':msg})
            qs = None
        
        if qs :
            request.session['session_id'] =qs.id    
            request.session['session_pw'] =qs.pw    
            request.session['session_name'] =qs.name   
            request.session['session_nick'] =qs.nickname   
            request.session['session_mtype'] =qs.membertype   
            request.session['session_email'] =qs.email_id  
            request.session['session_domain'] =qs.email_domain   
            # request.session['session_certifi'] =qs.certifi   
            # request.session['session_award'] =qs.award   
            request.session['session_skill'] =qs.skill
            print('id : ',qs.id)   
            # print('nickname : ',qs.nicknane)   
            # print('mtype : ',qs.membertype)
            
            # return render(request,'/')   
            return redirect('/')
        else:
            msg = '아이디 또는 패스워드가 일치하지 않습니다. 다시 입력하세요'   
            return render(request,'signin.html',{'msg':msg})
        
        
## 로그아웃
def logout(request):
    request.session.clear()
    return redirect('/')

## 회원수정
def membermodify(request):
    qs = Memberdata.objects.get(membertype='지원자')
    if request.session['session_mtype'] != '지원자':
        qs2 = Memberdata.objects.get(membertype='전문가')
        con = {'list':qs2}
        print('qs : ',qs2)
        return render(request,'membermod.html',con)
    else:
        con = {'list':qs}
        print('qs : ',qs)
        return render(request,'membermod.html',con)
    
    

## 회원수정 ok(반영) 하기
def memberupdated(request):
    if request.method == 'POST':
        id = request.POST.get('id')
        print('reqs id',id)
        name = request.POST.get('name')
        pw= request.POST.get('pw')
        repw = request.POST.get('repw')
        nickname = request.POST.get('nick')
        membertype = request.POST.get('mtype')
        email_id  = request.POST.get('email_id')
        email_domain = request.POST.get('domain')
        # certifi = request.POST.get('certifi')
        # award = request.POST.get('award')
        skill = request.POST.get('skill')
        file = request.FILES.get('file',None)
        qs = Memberdata.objects.get(id=id)
        qs.name = name
        qs.pw= pw
        qs.repw = repw
        qs.nickname = nickname
        qs.membertype = membertype
        qs.email_id  = email_id 
        qs.email_domain = email_domain
        qs.skill = skill
        if file:
            qs.image = file
            print('파일 저장 완료')
        qs.save()
        context= {'list':qs}
        return render(request,'mypage.html',context)

## 회원삭제(탈퇴)
def memberdrop(request):
    if request.method == 'GET':
        id = request.session['session_id']
        qs = Memberdata.objects.get(id=id)
        qs.delete()
        print('member delete completed !!')
        request.session.clear()
        return redirect('/')
    
## 분석 
def analsys(request):
    return render(request,'analsys.html')
   
    
    



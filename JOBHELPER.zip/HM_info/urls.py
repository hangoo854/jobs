from . import views
from django.urls import path

app_name ='HM_info'
urlpatterns = [
    path('cover_letter/',views.cover_letter,name='cover_letter'),
]

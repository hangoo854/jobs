from django.contrib import admin
# from resume.models import ResumeForm
from resume.models import ResumeForm,Reply

# Register your models here.
@admin.register(ResumeForm)
class ResumeAdmin(admin.ModelAdmin):
    list_display = ['r_no','r_title','member','r_education']

@admin.register(Reply)
class CommentAdmin(admin.ModelAdmin):
    list_display = ['c_no','member','c_content']
from . import views 
from django.urls import path

app_name='resume'

urlpatterns = [
    path('resume_write/',views.resume_write,name='resume_write'),
    path('resume_board/',views.resume_board,name='resume_board'),
    path('resume_board/highschool_board/',views.highschool_board,name='highschool_board'),
    path('highschool_view/',views.highschool_view,name='highschool_view'),
    path('<int:r_no>//resume_view/',views.resume_view,name='resume_view'),
    path('resume_menu/',views.resume_menu,name='resume_menu'),
    path('resume_write/highschool/',views.tab1,name='tab1'),
    path('resume_write/collage/',views.tab2,name='tab2'),
    path('resume_write/undergraduate/',views.tab3,name='tab3'),
    path('resume_write/graduate/',views.tab4,name='tab4'),
    path('<str:college>/resumedelete/',views.resumedelete,name='resumedelete'),
    path('<str:college>/highschooldelete/',views.highschooldelete,name='highschooldelete'),
    #답글
    path('<int:r_no>/reply/',views.Rreply,name='Rreply'),
    # 댓글 list
    path('commList/',views.commList,name='commList'),
    # 댓글 write
    path('commWrite/',views.commWrite,name='commWrite'),
    # 댓글 delete
    path('commDelete/',views.commDelete,name='commDelete'),
    # 댓글수정저장 updateOk
    path('commUpdateOk/',views.commUpdateOk,name='commUpdateOk'),
]



from django.contrib import admin
from HM_info.models import Ques1,Ques2,Ques3,Ques4
# Register your models here.


@admin.register(Ques1)
class Ques1Admin(admin.ModelAdmin):
    list_display = ['subques1','ques_content1','ques_keyword1']

@admin.register(Ques2)
class Ques2Admin(admin.ModelAdmin):
    list_display = ['subques2','ques_content2','ques_keyword2']

@admin.register(Ques3)
class Ques3Admin(admin.ModelAdmin):
    list_display = ['subques3','ques_content3','ques_keyword3']

@admin.register(Ques4)
class Ques4Admin(admin.ModelAdmin):
    list_display = ['subques4','ques_content4','ques_keyword4']
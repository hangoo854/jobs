from django.shortcuts import render

# Create your views here.
def cover_letter(request):
    return render(request,'kor.html')
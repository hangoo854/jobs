from django.db import models
from member.models import Memberdata,Education,Careerpath,Activities
from datetime import datetime


# Create your models here.
### 개인 이력 사항 데이터 focus
class ResumeForm(models.Model):
    r_no = models.AutoField(primary_key=True)
    r_title = models.CharField(max_length=200)
   
    ## 회원데이터 외래키
    member = models.ForeignKey(Memberdata,on_delete=models.DO_NOTHING,null=True)
    ## 학력데이터 외래키
    r_education = models.ForeignKey(Education,on_delete=models.DO_NOTHING,null=True)
   
    r_group = models.IntegerField(default=0)
    ## r_step : 상위 group에서 상위group보다 큰 step값이  1씩 증가한다. gt(최대값)보다 큰 값
    r_step = models.IntegerField(default=0)
    ## r_indent :  들여쓰기
    r_indent = models.IntegerField(default=0)
    ##  r_hit : 조회수
    r_hit = models.IntegerField(default=1)
    ## r_content : 경력 및 대외  사항 입력
    r_content = models.TextField()
    
    
    def __str__(self):
        return self.r_title
 
    
# 댓글   
class Reply(models.Model):
    # c_no:댓글번호, member:회원아이디, form:이력서번호
    # c_pw:댓글비밀번호, c_content:댓글내용, c_date:날짜
    c_no = models.AutoField(primary_key=True)
    member = models.ForeignKey(Memberdata,on_delete=models.DO_NOTHING,null=True)
    form = models.ForeignKey(ResumeForm,on_delete=models.CASCADE)
    c_pw = models.CharField(max_length=100,blank=True)
    c_content = models.TextField()
  
    
    


    

### NCS 데이터
#class NCS_dataset



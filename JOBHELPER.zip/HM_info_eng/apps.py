from django.apps import AppConfig


class HmInfoEngConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'HM_info_eng'

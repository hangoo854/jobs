from django.contrib import admin
from member.models import Memberdata
# Register your models here.

@admin.register(Memberdata)
class MeberAdmin(admin.ModelAdmin):
    list_display = ['nickname','email_id','email_domain','membertype','name','skill']
    
    
